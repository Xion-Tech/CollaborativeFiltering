﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CollaborativeFiltering
{
    class List<T1, T2>
    {
    }
}
